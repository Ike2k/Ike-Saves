# Ike Saves

Single-file static site. Upload `index.html` to a public GitHub repository and enable **Settings → Pages** with source `main` and folder `/ (root)`.

Live URL pattern: `https://YOUR-USERNAME.github.io/ike-saves`

